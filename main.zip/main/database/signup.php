<?php
 include('database/dbconfig.php');
include('functions.php');

if($_SERVER["REQUEST_METHOD"] == "POST"){

$fname=$_POST['fname'];
$age=$_POST['age'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$email=$_POST['email'];
$user = $_POST['username'];
$pass = $_POST['password'];
$cpassword = $_POST['cpassword'];

// $register_query = "INSERT INTO `form` (`fname`, `age`, `dob`, `gender`, `phone`, `email`, `username`, `password`, `cpassword`) 
// VALUES ('Heherfwefqefhehe',20,'01/01/2000','Male','117','g@yahoo.com','yuhyuh','12345', '12345')";
// $register_result = mysqli_query($conn, $register_query);
// echo("registration successful");

$register_query = "INSERT INTO `form` (`fname`, `age`, `dob`, `gender`, `phone`, `email`, `username`, `password`, `cpassword`) 
VALUES ('$fname','$age','$dob', '$gender' ,'$phone','$email','$user','$pass', '$cpassword')";


$register_result = mysqli_query($conn, $register_query);
header('homepage.php');
}



?>
