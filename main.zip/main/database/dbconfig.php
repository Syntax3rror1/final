<?php


$servername = "localhost";
$username="root";
$password="";
$dbname="db_web";
$conn = mysqli_connect($servername, $username, $password,$dbname);


?>
